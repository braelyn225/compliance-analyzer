# GRC Compliance Gap Analyzer 🔐

A Python tool for performing **Governance, Risk & Compliance (GRC) gap analyses** against industry-standard frameworks including **NIST CSF 2.0, ISO 27001:2022, SOC 2, HIPAA, and PCI DSS v4.0**.

---

## Features

- ✅ **5 built-in frameworks** – NIST CSF 2.0, ISO/IEC 27001:2022, SOC 2, HIPAA Security Rule, PCI DSS v4.0
- 📊 **Compliance scoring** – percentage-based score with weighted risk index
- 🗺️ **Remediation planning** – prioritized (High/Medium/Low) action items with 30/90/180-day targets
- 📄 **Multi-format reports** – JSON, Markdown, CSV
- 🔄 **Cross-framework analysis** – compare posture across multiple standards simultaneously
- 🖥️ **CLI + Python API** – use interactively or integrate into pipelines

---

## Quick Start

### Install

```bash
git clone https://github.com/<your-username>/grc-gap-analyzer.git
cd grc-gap-analyzer
pip install -e ".[dev]"
```

### Run interactively (wizard)

```bash
python -m grc_analyzer
```

### Run with a pre-filled assessment file

```bash
python -m grc_analyzer --input sample_assessment.json --framework NIST_CSF --format markdown
```

### List available frameworks

```bash
python -m grc_analyzer --list-frameworks
```

---

## Python API

```python
from grc_analyzer import GapAnalyzer, ReportGenerator

# 1. Create analyzer
analyzer = GapAnalyzer(org_name="Acme Corp")

# 2. Load assessment responses
# status values: "compliant" | "partial" | "non_compliant" | "not_applicable"
responses = {
    "ID.AM-01": "compliant",
    "ID.AM-02": "partial",
    "PR.AA-01": "non_compliant",
    # ... all control IDs for the framework
}
analyzer.load_assessment("NIST_CSF", responses)

# 3. Analyze
result = analyzer.analyze("NIST_CSF")
print(f"Compliance Score: {result['compliance_score']}%")
print(f"Risk Score: {result['risk_score']}")

# 4. Get prioritized remediation plan
plan = analyzer.remediation_plan("NIST_CSF")
for item in plan[:5]:
    print(f"[{item['priority']}] {item['id']} – {item['title']}")

# 5. Generate reports
reporter = ReportGenerator(analyzer, output_dir="reports")
reporter.to_json("NIST_CSF")
reporter.to_markdown("NIST_CSF")
reporter.to_csv("NIST_CSF")
```

### Load from JSON file

```python
analyzer.load_from_json("assessment.json")
```

Assessment JSON format:

```json
{
  "NIST_CSF": {
    "ID.AM-01": "compliant",
    "ID.AM-02": "partial",
    "PR.AA-01": "non_compliant"
  },
  "ISO_27001": {
    "5.1": "compliant",
    "5.2": "non_compliant"
  }
}
```

---

## Framework Coverage

| Key | Framework | Controls |
|-----|-----------|----------|
| `NIST_CSF` | NIST Cybersecurity Framework 2.0 | 22 |
| `ISO_27001` | ISO/IEC 27001:2022 | 20 |
| `SOC2` | SOC 2 Trust Services Criteria | 17 |
| `HIPAA` | HIPAA Security Rule | 16 |
| `PCI_DSS` | PCI DSS v4.0 | 16 |

---

## Report Example (Markdown)

```
| Status | Count |
|--------|-------|
| ✅ Compliant | 8 |
| ⚠️ Partial | 5 |
| ❌ Non-Compliant | 7 |
| N/A | 2 |
| Total | 22 |
```

---

## Running Tests

```bash
pytest tests/ -v
```

---

## Project Structure

```
grc-gap-analyzer/
├── grc_analyzer/
│   ├── __init__.py          # Public API
│   ├── __main__.py          # python -m grc_analyzer entry point
│   ├── frameworks.py        # Control libraries (NIST, ISO, SOC2, HIPAA, PCI)
│   ├── analyzer.py          # Gap analysis engine
│   ├── reporter.py          # JSON / Markdown / CSV report generators
│   └── cli.py               # Command-line interface
├── tests/
│   └── test_analyzer.py
├── reports/                 # Generated reports (git-ignored)
├── sample_assessment.json   # Example assessment input
├── setup.py
├── pyproject.toml
├── LICENSE
└── README.md
```

---

## Compliance Score Formula

```
score = (compliant + 0.5 × partial) / applicable_controls × 100
```

Risk score is a weighted sum where High-priority gaps = 3 pts, Medium = 2 pts, Low = 1 pt.

---

## Extending with Custom Frameworks

Add a new entry to `FRAMEWORKS` dict in `grc_analyzer/frameworks.py`:

```python
FRAMEWORKS["MY_FRAMEWORK"] = {
    "name": "My Custom Framework",
    "version": "1.0",
    "controls": [
        {"id": "MC-01", "domain": "Security", "title": "Control Title",
         "description": "Control description.", "priority": "H"},
    ],
}
```

---

## License

MIT
