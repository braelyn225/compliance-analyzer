from setuptools import setup, find_packages

setup(
    name="grc-gap-analyzer",
    version="1.0.0",
    description="GRC Compliance Gap Analyzer for NIST CSF, ISO 27001, SOC 2, HIPAA, PCI DSS",
    author="Your Name",
    author_email="you@example.com",
    license="MIT",
    packages=find_packages(),
    python_requires=">=3.9",
    install_requires=[],
    extras_require={
        "dev": ["pytest>=7.0"],
    },
    entry_points={
        "console_scripts": [
            "grc-analyzer=grc_analyzer.cli:main",
        ],
    },
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Topic :: Security",
        "Topic :: Office/Business",
    ],
)
