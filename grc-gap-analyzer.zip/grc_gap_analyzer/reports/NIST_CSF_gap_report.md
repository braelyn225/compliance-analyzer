# GRC Compliance Gap Report

| Field | Value |
|-------|-------|
| **Organization** | Demo Corporation |
| **Framework** | NIST Cybersecurity Framework 2.0 |
| **Assessment Date** | 2026-02-28 |
| **Compliance Score** | 54.5% |
| **Risk Score** | 37 |

## Summary

| Status | Count |
|--------|-------|
| ✅ Compliant | 8 |
| ⚠️ Partial | 8 |
| ❌ Non-Compliant | 6 |
| N/A | 0 |
| **Total** | **22** |

## Gaps & Remediation Plan

| ID | Domain | Title | Priority | Status | Recommendation |
|----|--------|-------|----------|--------|----------------|
| DE.AE-02 | DETECT | Event Analysis | H | non_compliant | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| ID.AM-02 | IDENTIFY | Asset Inventory – Software | H | partial | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| ID.RA-01 | IDENTIFY | Vulnerability Identification | H | non_compliant | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| ID.RA-05 | IDENTIFY | Threats & Vulnerabilities | H | partial | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| PR.AA-05 | PROTECT | Least Privilege | H | partial | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| PR.DS-02 | PROTECT | Data in Transit | H | non_compliant | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| PR.IR-01 | PROTECT | Network Integrity | H | partial | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| RC.RP-01 | RECOVER | Recovery Planning | H | partial | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| RS.MA-01 | RESPOND | Incident Management | H | partial | 🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately. |
| DE.CM-03 | DETECT | User Activity Monitoring | M | partial | 🟡 MEDIUM PRIORITY – Address within 90 days. Include in next sprint. |
| GV.SC-01 | GOVERN | Supply Chain Risk Management | M | partial | 🟡 MEDIUM PRIORITY – Address within 90 days. Include in next sprint. |
| ID.AM-05 | IDENTIFY | Asset Vulnerability Management | M | non_compliant | 🟡 MEDIUM PRIORITY – Address within 90 days. Include in next sprint. |
| PR.PS-01 | PROTECT | Configuration Management | M | non_compliant | 🟡 MEDIUM PRIORITY – Address within 90 days. Include in next sprint. |
| RS.CO-02 | RESPOND | Incident Reporting | M | non_compliant | 🟡 MEDIUM PRIORITY – Address within 90 days. Include in next sprint. |

## Compliant Controls

| ID | Domain | Title |
|----|--------|-------|
| GV.OC-01 | GOVERN | Organizational Context |
| GV.RM-01 | GOVERN | Risk Management Strategy |
| ID.AM-01 | IDENTIFY | Asset Inventory – Hardware |
| PR.AA-01 | PROTECT | Identity Management |
| PR.AA-03 | PROTECT | Access Control |
| PR.DS-01 | PROTECT | Data at Rest |
| DE.CM-01 | DETECT | Continuous Monitoring |
| RC.CO-03 | RECOVER | Recovery Communication |