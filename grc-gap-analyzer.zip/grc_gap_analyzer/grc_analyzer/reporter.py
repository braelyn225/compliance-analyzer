"""
Report generators: JSON, Markdown, CSV.
"""
from __future__ import annotations
import csv
import json
import os
from datetime import datetime
from .analyzer import GapAnalyzer


class ReportGenerator:
    def __init__(self, analyzer: GapAnalyzer, output_dir: str = "reports"):
        self.analyzer = analyzer
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def _path(self, name: str) -> str:
        return os.path.join(self.output_dir, name)

    # ── JSON ──────────────────────────────────────────────────────────────────
    def to_json(self, framework: str) -> str:
        result = self.analyzer.analyze(framework)
        path = self._path(f"{framework}_gap_report.json")
        with open(path, "w") as f:
            json.dump(result, f, indent=2)
        return path

    # ── Markdown ──────────────────────────────────────────────────────────────
    def to_markdown(self, framework: str) -> str:
        result = self.analyzer.analyze(framework)
        plan = self.analyzer.remediation_plan(framework)
        lines = [
            f"# GRC Compliance Gap Report",
            f"",
            f"| Field | Value |",
            f"|-------|-------|",
            f"| **Organization** | {result['org_name']} |",
            f"| **Framework** | {result['framework_name']} |",
            f"| **Assessment Date** | {result['timestamp'][:10]} |",
            f"| **Compliance Score** | {result['compliance_score']}% |",
            f"| **Risk Score** | {result['risk_score']} |",
            f"",
            f"## Summary",
            f"",
            f"| Status | Count |",
            f"|--------|-------|",
            f"| ✅ Compliant | {result['compliant']} |",
            f"| ⚠️ Partial | {result['partial']} |",
            f"| ❌ Non-Compliant | {result['non_compliant']} |",
            f"| N/A | {result['not_applicable']} |",
            f"| **Total** | **{result['total_controls']}** |",
            f"",
            f"## Gaps & Remediation Plan",
            f"",
            f"| ID | Domain | Title | Priority | Status | Recommendation |",
            f"|----|--------|-------|----------|--------|----------------|",
        ]
        for item in plan:
            lines.append(
                f"| {item['id']} | {item['domain']} | {item['title']} "
                f"| {item['priority']} | {item['status']} | {item['recommendation']} |"
            )
        if result["compliant_controls"]:
            lines += [
                "",
                "## Compliant Controls",
                "",
                "| ID | Domain | Title |",
                "|----|--------|-------|",
            ]
            for c in result["compliant_controls"]:
                lines.append(f"| {c['id']} | {c['domain']} | {c['title']} |")

        md = "\n".join(lines)
        path = self._path(f"{framework}_gap_report.md")
        with open(path, "w") as f:
            f.write(md)
        return path

    # ── CSV ───────────────────────────────────────────────────────────────────
    def to_csv(self, framework: str) -> str:
        result = self.analyzer.analyze(framework)
        all_controls = (
            result["gaps"]
            + result["partials"]
            + result["compliant_controls"]
        )
        path = self._path(f"{framework}_gap_report.csv")
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(
                f,
                fieldnames=["id", "domain", "title", "description", "priority", "status"],
            )
            writer.writeheader()
            for c in all_controls:
                writer.writerow({k: c.get(k, "") for k in writer.fieldnames})
        return path

    # ── Cross-framework CSV ───────────────────────────────────────────────────
    def cross_framework_csv(self) -> str:
        rows = self.analyzer.cross_framework_summary()
        path = self._path("cross_framework_summary.csv")
        if not rows:
            return path
        with open(path, "w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
            writer.writeheader()
            writer.writerows(rows)
        return path
