"""GRC Compliance Gap Analyzer."""
from .analyzer import GapAnalyzer
from .reporter import ReportGenerator
from .frameworks import FRAMEWORKS

__version__ = "1.0.0"
__all__ = ["GapAnalyzer", "ReportGenerator", "FRAMEWORKS"]
