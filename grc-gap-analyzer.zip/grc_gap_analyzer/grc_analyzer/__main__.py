from grc_analyzer.cli import main
main()
