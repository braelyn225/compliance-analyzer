"""
Core gap analysis engine.
"""
from __future__ import annotations
import json
from datetime import datetime
from typing import Optional
from .frameworks import FRAMEWORKS

STATUS_VALUES = ("compliant", "partial", "non_compliant", "not_applicable")
PRIORITY_WEIGHT = {"H": 3, "M": 2, "L": 1}


class GapAnalyzer:
    """Perform a GRC compliance gap analysis against one or more frameworks."""

    def __init__(self, org_name: str = "My Organization"):
        self.org_name = org_name
        self.assessments: dict[str, dict] = {}  # framework -> {control_id -> status}

    # ── data loading ──────────────────────────────────────────────────────────
    def load_assessment(self, framework: str, responses: dict[str, str]) -> None:
        """
        Load assessment responses for a framework.

        Parameters
        ----------
        framework : str
            Framework key, e.g. "NIST_CSF".
        responses : dict
            Mapping of control_id -> status (compliant/partial/non_compliant/not_applicable).
        """
        if framework not in FRAMEWORKS:
            raise ValueError(f"Unknown framework '{framework}'. Available: {list(FRAMEWORKS)}")
        for status in responses.values():
            if status not in STATUS_VALUES:
                raise ValueError(f"Invalid status '{status}'. Must be one of {STATUS_VALUES}")
        self.assessments[framework] = responses

    def load_from_json(self, path: str) -> None:
        """Load one or more framework assessments from a JSON file."""
        with open(path) as f:
            data = json.load(f)
        for fw, responses in data.items():
            self.load_assessment(fw, responses)

    # ── analysis ──────────────────────────────────────────────────────────────
    def analyze(self, framework: str) -> dict:
        """Return gap analysis results for a single framework."""
        if framework not in self.assessments:
            raise ValueError(f"No assessment loaded for '{framework}'.")

        controls = FRAMEWORKS[framework]["controls"]
        responses = self.assessments[framework]
        gaps, partials, compliant_list, na_list = [], [], [], []

        for ctrl in controls:
            cid = ctrl["id"]
            status = responses.get(cid, "non_compliant")
            entry = {**ctrl, "status": status}
            if status == "non_compliant":
                gaps.append(entry)
            elif status == "partial":
                partials.append(entry)
            elif status == "compliant":
                compliant_list.append(entry)
            else:
                na_list.append(entry)

        total_applicable = len(controls) - len(na_list)
        score = (
            (len(compliant_list) + 0.5 * len(partials)) / total_applicable * 100
            if total_applicable else 0
        )

        # Weighted risk score (higher = more risk)
        risk_score = sum(
            PRIORITY_WEIGHT.get(c["priority"], 1)
            for c in gaps + partials
        )

        return {
            "framework": framework,
            "framework_name": FRAMEWORKS[framework]["name"],
            "org_name": self.org_name,
            "timestamp": datetime.utcnow().isoformat() + "Z",
            "total_controls": len(controls),
            "compliant": len(compliant_list),
            "partial": len(partials),
            "non_compliant": len(gaps),
            "not_applicable": len(na_list),
            "compliance_score": round(score, 1),
            "risk_score": risk_score,
            "gaps": gaps,
            "partials": partials,
            "compliant_controls": compliant_list,
        }

    def analyze_all(self) -> dict[str, dict]:
        """Analyze all loaded frameworks."""
        return {fw: self.analyze(fw) for fw in self.assessments}

    # ── remediation ───────────────────────────────────────────────────────────
    REMEDIATION_HINTS = {
        "H": "🔴 HIGH PRIORITY – Address within 30 days. Assign owner immediately.",
        "M": "🟡 MEDIUM PRIORITY – Address within 90 days. Include in next sprint.",
        "L": "🟢 LOW PRIORITY – Address within 180 days. Schedule for future cycle.",
    }

    def remediation_plan(self, framework: str) -> list[dict]:
        """Return a prioritized remediation plan for a framework."""
        result = self.analyze(framework)
        items = result["gaps"] + result["partials"]
        items.sort(key=lambda x: (-PRIORITY_WEIGHT.get(x["priority"], 1), x["id"]))
        return [
            {
                **item,
                "recommendation": self.REMEDIATION_HINTS.get(item["priority"], ""),
            }
            for item in items
        ]

    # ── cross-framework ───────────────────────────────────────────────────────
    def cross_framework_summary(self) -> list[dict]:
        """Summary table across all loaded frameworks."""
        rows = []
        for fw, result in self.analyze_all().items():
            rows.append({
                "framework": result["framework_name"],
                "score": result["compliance_score"],
                "compliant": result["compliant"],
                "partial": result["partial"],
                "non_compliant": result["non_compliant"],
                "risk_score": result["risk_score"],
            })
        return rows
