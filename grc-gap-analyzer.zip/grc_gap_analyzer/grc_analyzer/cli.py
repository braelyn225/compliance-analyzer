"""
Command-line interface for the GRC Compliance Gap Analyzer.

Usage examples:
    # Interactive wizard
    python -m grc_analyzer

    # Run with a JSON assessment file
    python -m grc_analyzer --input assessment.json --framework NIST_CSF --format markdown

    # List available frameworks
    python -m grc_analyzer --list-frameworks
"""
from __future__ import annotations
import argparse
import json
import sys
from .analyzer import GapAnalyzer, STATUS_VALUES
from .frameworks import FRAMEWORKS
from .reporter import ReportGenerator


STATUS_EMOJI = {
    "compliant": "✅",
    "partial": "⚠️",
    "non_compliant": "❌",
    "not_applicable": "➖",
}


def list_frameworks() -> None:
    print("\nAvailable Frameworks\n" + "=" * 40)
    for key, fw in FRAMEWORKS.items():
        print(f"  {key:15} – {fw['name']} ({len(fw['controls'])} controls)")
    print()


def interactive_wizard(analyzer: GapAnalyzer) -> str:
    """Walk the user through selecting a framework and rating each control."""
    print("\n" + "=" * 60)
    print("  GRC Compliance Gap Analyzer – Interactive Mode")
    print("=" * 60)
    analyzer.org_name = input("\nOrganization name [My Organization]: ").strip() or "My Organization"

    print()
    list_frameworks()
    fw_key = input("Select framework key: ").strip().upper()
    if fw_key not in FRAMEWORKS:
        print(f"Unknown framework. Choices: {list(FRAMEWORKS.keys())}")
        sys.exit(1)

    controls = FRAMEWORKS[fw_key]["controls"]
    responses: dict[str, str] = {}
    print(f"\nAssessing {len(controls)} controls. For each, enter status:")
    print("  [c] compliant  [p] partial  [n] non_compliant  [x] not_applicable\n")

    shortcut = {"c": "compliant", "p": "partial", "n": "non_compliant", "x": "not_applicable"}
    for ctrl in controls:
        while True:
            ans = input(f"  [{ctrl['id']}] {ctrl['title']} (c/p/n/x): ").strip().lower()
            if ans in shortcut:
                responses[ctrl["id"]] = shortcut[ans]
                break
            print("    Please enter c, p, n, or x.")

    analyzer.load_assessment(fw_key, responses)
    return fw_key


def print_summary(result: dict) -> None:
    print("\n" + "=" * 60)
    print(f"  Gap Analysis Results – {result['framework_name']}")
    print("=" * 60)
    print(f"  Organization   : {result['org_name']}")
    print(f"  Compliance Score: {result['compliance_score']}%")
    print(f"  Risk Score      : {result['risk_score']}")
    print()
    for s in ("compliant", "partial", "non_compliant", "not_applicable"):
        label = s.replace("_", " ").title()
        count = result[s if s != "non_compliant" else "non_compliant"]
        # handle key differences
        key_map = {"compliant": "compliant", "partial": "partial",
                   "non_compliant": "non_compliant", "not_applicable": "not_applicable"}
        print(f"  {STATUS_EMOJI[s]} {label:20}: {result[key_map[s]]}")
    print()

    if result["gaps"]:
        print("  Top Gaps (High Priority):")
        for g in [x for x in result["gaps"] if x["priority"] == "H"][:5]:
            print(f"    ❌ [{g['id']}] {g['title']}")
    print()


def main(argv: list[str] | None = None) -> None:
    parser = argparse.ArgumentParser(
        prog="grc-analyzer",
        description="GRC Compliance Gap Analyzer",
    )
    parser.add_argument("--list-frameworks", action="store_true", help="List all supported frameworks")
    parser.add_argument("--input", "-i", help="Path to JSON assessment file")
    parser.add_argument("--framework", "-f", help="Framework key (e.g. NIST_CSF)")
    parser.add_argument("--org", "-o", default="My Organization", help="Organization name")
    parser.add_argument("--format", choices=["json", "markdown", "csv", "all"], default="all", help="Output report format")
    parser.add_argument("--output-dir", default="reports", help="Directory for output reports")

    args = parser.parse_args(argv)

    if args.list_frameworks:
        list_frameworks()
        return

    analyzer = GapAnalyzer(org_name=args.org)

    if args.input:
        analyzer.load_from_json(args.input)
        fw_key = args.framework or list(analyzer.assessments.keys())[0]
    else:
        fw_key = interactive_wizard(analyzer)

    result = analyzer.analyze(fw_key)
    print_summary(result)

    reporter = ReportGenerator(analyzer, output_dir=args.output_dir)

    if args.format in ("json", "all"):
        p = reporter.to_json(fw_key)
        print(f"  JSON report   → {p}")
    if args.format in ("markdown", "all"):
        p = reporter.to_markdown(fw_key)
        print(f"  Markdown report → {p}")
    if args.format in ("csv", "all"):
        p = reporter.to_csv(fw_key)
        print(f"  CSV report    → {p}")
    print()


if __name__ == "__main__":
    main()
