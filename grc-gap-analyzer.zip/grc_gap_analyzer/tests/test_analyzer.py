"""Unit tests for GRC Compliance Gap Analyzer."""
import os, sys, json, tempfile, pytest
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from grc_analyzer import GapAnalyzer, ReportGenerator, FRAMEWORKS


@pytest.fixture
def sample_responses():
    controls = FRAMEWORKS["NIST_CSF"]["controls"]
    responses = {}
    for i, ctrl in enumerate(controls):
        responses[ctrl["id"]] = ["compliant", "partial", "non_compliant"][i % 3]
    return responses


def test_frameworks_loaded():
    assert len(FRAMEWORKS) >= 5
    for fw, data in FRAMEWORKS.items():
        assert "controls" in data
        assert len(data["controls"]) > 0


def test_load_and_analyze(sample_responses):
    analyzer = GapAnalyzer("Test Corp")
    analyzer.load_assessment("NIST_CSF", sample_responses)
    result = analyzer.analyze("NIST_CSF")
    assert result["total_controls"] == len(FRAMEWORKS["NIST_CSF"]["controls"])
    assert result["compliance_score"] >= 0
    assert result["compliance_score"] <= 100
    assert result["compliant"] + result["partial"] + result["non_compliant"] + result["not_applicable"] == result["total_controls"]


def test_invalid_framework(sample_responses):
    analyzer = GapAnalyzer()
    with pytest.raises(ValueError):
        analyzer.load_assessment("UNKNOWN_FW", sample_responses)


def test_invalid_status():
    analyzer = GapAnalyzer()
    with pytest.raises(ValueError):
        analyzer.load_assessment("NIST_CSF", {"ID.AM-01": "unknown_status"})


def test_remediation_plan(sample_responses):
    analyzer = GapAnalyzer()
    analyzer.load_assessment("NIST_CSF", sample_responses)
    plan = analyzer.remediation_plan("NIST_CSF")
    for item in plan:
        assert item["status"] in ("non_compliant", "partial")
        assert "recommendation" in item


def test_reports(sample_responses, tmp_path):
    analyzer = GapAnalyzer("ACME")
    analyzer.load_assessment("NIST_CSF", sample_responses)
    reporter = ReportGenerator(analyzer, output_dir=str(tmp_path))
    assert os.path.exists(reporter.to_json("NIST_CSF"))
    assert os.path.exists(reporter.to_markdown("NIST_CSF"))
    assert os.path.exists(reporter.to_csv("NIST_CSF"))


def test_cross_framework(sample_responses):
    analyzer = GapAnalyzer()
    for fw in ["NIST_CSF", "SOC2"]:
        ctrls = FRAMEWORKS[fw]["controls"]
        r = {c["id"]: ["compliant", "partial", "non_compliant"][i % 3] for i, c in enumerate(ctrls)}
        analyzer.load_assessment(fw, r)
    summary = analyzer.cross_framework_summary()
    assert len(summary) == 2


def test_load_from_json(sample_responses, tmp_path):
    path = str(tmp_path / "assessment.json")
    with open(path, "w") as f:
        json.dump({"NIST_CSF": sample_responses}, f)
    analyzer = GapAnalyzer()
    analyzer.load_from_json(path)
    result = analyzer.analyze("NIST_CSF")
    assert result["compliance_score"] >= 0
